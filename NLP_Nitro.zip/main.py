#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
main file: calls and runs test, then calls and runs the GUI 
"""
from ComplexifierGUI import ComplexifierGUI

gui = ComplexifierGUI()
gui.run_complexifier_GUI()

